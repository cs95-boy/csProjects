creating a calculator
